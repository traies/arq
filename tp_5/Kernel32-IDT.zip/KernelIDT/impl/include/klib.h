/*
 * klib.h
 *
 *  Created on: Apr 18, 2010
 *      Author: anizzomc
 */

#ifndef KLIB_H_
#define KLIB_H_

#include "types.h"

#endif /* KLIB_H_ */
