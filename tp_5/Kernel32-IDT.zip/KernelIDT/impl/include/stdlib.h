/*
 * stdlib.h
 *
 *  Created on: Apr 18, 2010
 *      Author: anizzomc
 */

#ifndef STDLIB_H_
#define STDLIB_H_


#define NULL (void*)0


#endif /* STDLIB_H_ */
